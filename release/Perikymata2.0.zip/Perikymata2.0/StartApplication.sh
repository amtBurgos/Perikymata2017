#!/bin/bash
clear
echo "Starting Perikymata 2.0 Application"
java -jar Perikymata2.0.jar
echo "Stoping server"
./PythonApp/StopServerLinux.sh
echo "Application finished, press any key to exit..."
read key
exit
