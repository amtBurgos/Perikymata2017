#!/bin/bash
clear
python3 ServerSocket.py
